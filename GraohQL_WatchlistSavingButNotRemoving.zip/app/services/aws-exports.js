const awsmobile = {
    Auth: {
      Cognito: {
        userPoolId: "eu-west-1_GbdAS6D4M",
        userPoolClientId: "2tbc22gviqulfg9u0no6k61288",
        region: "eu-west-1"
      }
    }
  }
  
  export default awsmobile
    