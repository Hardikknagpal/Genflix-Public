import { LoginScreen } from './screens/LoginScreen';

export default function LoginRoute() {
  return <LoginScreen />;
} 