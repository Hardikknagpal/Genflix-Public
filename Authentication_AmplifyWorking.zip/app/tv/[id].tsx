import MovieDetailsScreen from '../screens/MovieDetailsScreen';

export default function TVDetailsRoute() {
  return <MovieDetailsScreen />;
} 