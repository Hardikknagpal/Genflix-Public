import MovieDetailsScreen from '../screens/MovieDetailsScreen';

export default function MovieDetailsRoute() {
  return <MovieDetailsScreen />;
} 