// import HomeScreen from './screens/HomeScreen';

// export default function App() {
//   return <HomeScreen />;
// }

import { Redirect } from "expo-router";

export default function Index() {
  return <Redirect href="/(tabs)" />;
}





// import { Redirect } from "expo-router"

// export default function Index() {
//   return <Redirect href="/(drawer)/(tabs)" />
// }

