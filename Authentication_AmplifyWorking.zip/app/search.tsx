import SearchScreen from './screens/SearchScreen';

export default function SearchRoute() {
  return <SearchScreen />;
} 